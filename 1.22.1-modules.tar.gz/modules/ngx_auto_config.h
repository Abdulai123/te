#define NGX_CONFIGURE " --with-ld-opt=-Wl,-rpath,/usr/local/libm,-lpcre --with-compat --add-dynamic-module=naxsi/naxsi_src --add-dynamic-module=headers-more-nginx-module --add-dynamic-module=echo-nginx-module --add-dynamic-module=ngx_devel_kit --add-dynamic-module=lua-nginx-module"

#ifndef NGX_COMPILER
#define NGX_COMPILER  "gcc 12.2.0 (Debian 12.2.0-14) "
#endif

